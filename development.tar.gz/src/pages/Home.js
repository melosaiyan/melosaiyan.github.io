//import logo from './logo.svg';
import '../App.css';
import * as React from 'react';



function Home() {
  return (
    <div className="Home">
          <h1>Welcome!</h1>
          <p>
            Welcome to your Valentine's Day website, <br/>Heather!
          </p>
          <p>
          I wanted to make you your own app with Valentine's Day goodies. Please click the menu to check each one out! I would go in order, starting from the top :)
          </p>
    </div>
  );
}

export default Home;
